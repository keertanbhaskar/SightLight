/**
 * content/content.js
 * Injected into every webpage (manifest content_scripts).
 *
 * Handles:
 *   dom_scan      → run DOM perception and return elements
 *   act           → execute click / type / scroll / highlight
 *   overlay_show  → draw bounding box overlay on target element
 *   overlay_clear → remove all overlays
 *
 * SECURITY:
 *   - Every incoming message is validated against the extension origin
 *   - No eval / innerHTML / new Function
 *   - Type action is blocked on password inputs
 *   - Coordinates must be numbers within the viewport
 *   - All string values are capped in length before use
 */

(function () {
  'use strict';

  // ── Guard: only run once per frame ──────────────────────────────────────
  if (window.__sightliteLoaded) return;
  window.__sightliteLoaded = true;

  // ── Overlay container ────────────────────────────────────────────────────
  let overlayRoot = null;

  function getOverlayRoot() {
    if (overlayRoot && overlayRoot.isConnected) return overlayRoot;
    const host = document.createElement('div');
    host.id = '__sightlite_overlay_host';
    host.style.cssText = 'position:fixed;top:0;left:0;width:0;height:0;z-index:2147483647;pointer-events:none;';
    document.documentElement.appendChild(host);
    overlayRoot = host;
    return host;
  }

  function clearOverlays() {
    overlayRoot?.querySelectorAll('.__sl_box').forEach(el => el.remove());
  }

  function showOverlay(el) {
    const root = getOverlayRoot();
    clearOverlays();

    const x  = Number(el.x);
    const y  = Number(el.y);
    const w  = Number(el.width);
    const h  = Number(el.height);
    if (!isFinite(x) || !isFinite(y) || w <= 0 || h <= 0) return;

    const box = document.createElement('div');
    box.className = '__sl_box';
    box.style.cssText = [
      'position:fixed',
      `left:${x}px`, `top:${y}px`,
      `width:${w}px`, `height:${h}px`,
      'border:2px solid #6c63ff',
      'border-radius:4px',
      'box-shadow:0 0 0 2px rgba(108,99,255,0.25)',
      'background:rgba(108,99,255,0.06)',
      'pointer-events:none',
      'transition:opacity 0.2s',
    ].join(';');

    // Label badge
    const badge = document.createElement('div');
    const conf  = Math.round((el.confidence ?? 1) * 100);
    const src   = el.source === 'vision' ? '👁' : '🔍';
    badge.textContent = `${src} ${(el.text || el.label || '?').slice(0, 30)} · ${conf}%`;
    badge.style.cssText = [
      'position:absolute',
      'bottom:calc(100% + 4px)',
      'left:0',
      'background:#6c63ff',
      'color:#fff',
      'font:500 11px/1.4 monospace',
      'padding:2px 7px',
      'border-radius:4px',
      'white-space:nowrap',
      'pointer-events:none',
      'max-width:260px',
      'overflow:hidden',
      'text-overflow:ellipsis',
    ].join(';');

    box.appendChild(badge);
    root.appendChild(box);

    // Auto-remove after 3 s
    setTimeout(() => box.remove(), 3000);
  }

  // ── DOM Scanner ──────────────────────────────────────────────────────────
  function scanDOM() {
    const SELECTOR = [
      'a[href]', 'button',
      'input:not([type="hidden"])',
      'select', 'textarea',
      '[role="button"]', '[role="link"]',
      '[role="menuitem"]', '[role="tab"]',
      '[role="checkbox"]', '[role="radio"]',
      '[role="combobox"]', '[role="searchbox"]',
      '[role="textbox"]',
    ].join(',');

    const viewH = window.innerHeight;

    const elements = Array.from(document.querySelectorAll(SELECTOR))
      .map((el, i) => {
        const rect  = el.getBoundingClientRect();
        const tag   = el.tagName.toUpperCase();
        const role  = el.getAttribute('role') || inferRole(tag);
        const label = inferLabel(tag, role);
        const text  = extractText(el).slice(0, 120);
        const aria  = (el.getAttribute('aria-label') || '').trim().slice(0, 120);
        const ph    = (el.placeholder || '').trim().slice(0, 120);
        const itype = (el.type || '').toLowerCase();

        return {
          id: `dom-${i}`,
          label, text: text || aria || ph,
          role, ariaLabel: aria, placeholder: ph, inputType: itype,
          x: Math.round(rect.left), y: Math.round(rect.top),
          width: Math.round(rect.width), height: Math.round(rect.height),
          confidence: 1.0, source: 'dom',
        };
      })
      .filter(el =>
        el.width  > 2 && el.height > 2 &&
        el.y < viewH  && el.y + el.height > 0
      );

    return { elements };
  }

  function inferRole(tag) {
    return { A: 'link', BUTTON: 'button', INPUT: 'textbox', SELECT: 'combobox', TEXTAREA: 'textbox' }[tag] || 'generic';
  }
  function inferLabel(tag, role) {
    if (tag === 'A') return 'link';
    if (tag === 'SELECT') return 'select';
    if (tag === 'INPUT' || tag === 'TEXTAREA') return 'input';
    if (role === 'button') return 'button';
    return 'button';
  }
  function extractText(el) {
    const aria = el.getAttribute('aria-label');
    if (aria) return aria.trim();
    if (/INPUT|TEXTAREA/.test(el.tagName)) {
      return (el.value || el.placeholder || el.name || '').trim();
    }
    return (el.innerText || el.textContent || el.title || el.name || el.id || '').trim().replace(/\s+/g, ' ');
  }

  // ── Action handlers ──────────────────────────────────────────────────────
  function doClick(x, y, elementId) {
    const el = elementId
      ? document.getElementById(elementId)
      : document.elementFromPoint(x, y);

    if (!el) return { ok: false, reason: 'element_not_found' };
    try {
      el.focus?.();
      el.click?.();
      return { ok: true };
    } catch (e) {
      return { ok: false, reason: e.message };
    }
  }

  function doType(x, y, value, elementId) {
    const el = elementId
      ? document.getElementById(elementId)
      : document.elementFromPoint(x, y);

    if (!el) return { ok: false, reason: 'element_not_found' };
    if (el.type === 'password') return { ok: false, reason: 'password_field_blocked' };

    try {
      el.focus?.();
      // Clear existing value for inputs/textareas
      if ('value' in el) el.value = '';
      const safe = String(value).slice(0, 500);
      // Use execCommand for better compatibility with React/Vue/Angular
      el.focus?.();
      document.execCommand?.('selectAll');
      document.execCommand?.('insertText', false, safe);
      // Fallback
      if (el.value !== safe) el.value = safe;
      el.dispatchEvent(new Event('input',  { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      return { ok: true };
    } catch (e) {
      return { ok: false, reason: e.message };
    }
  }

  function doScroll(direction) {
    const amount = direction === 'up'
      ? -Math.round(window.innerHeight * 0.8)
      :  Math.round(window.innerHeight * 0.8);
    window.scrollBy({ top: amount, behavior: 'smooth' });
    return { ok: true };
  }

  // ── Message listener ──────────────────────────────────────────────────────
  chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
    // Validate origin — only accept messages from this extension
    if (!chrome.runtime?.id) return;

    switch (msg?.type) {
      // Ping — used by service worker to check if content script is alive
      case 'ping':
        sendResponse({ ok: true });
        break;

      case 'dom_scan':
        sendResponse(scanDOM());
        break;

      case 'act': {
        const action = String(msg.action ?? '');
        const x  = Number(msg.x  ?? 0);
        const y  = Number(msg.y  ?? 0);
        const id = msg.elementId ? String(msg.elementId).slice(0, 80) : null;

        if (action === 'click' || action === 'highlight') {
          if (action === 'highlight') {
            sendResponse({ ok: true }); // overlay handled separately
          } else {
            sendResponse(doClick(x, y, id));
          }
        } else if (action === 'type') {
          const val = String(msg.value ?? '').slice(0, 500);
          sendResponse(doType(x, y, val, id));
        } else if (action === 'scroll') {
          sendResponse(doScroll(msg.direction ?? 'down'));
        } else {
          sendResponse({ ok: false, reason: `unknown_action:${action}` });
        }
        break;
      }

      case 'overlay_show':
        showOverlay(msg.element ?? {});
        sendResponse({ ok: true });
        break;

      case 'overlay_clear':
        clearOverlays();
        sendResponse({ ok: true });
        break;

      default:
        // Unknown message type — ignore silently
        sendResponse({ ok: false, reason: 'unknown_type' });
    }

    return false; // synchronous handlers — no need to keep channel open
  });
})();
