/**
 * background/service-worker.js   (Manifest V3 service worker)
 *
 * Responsibilities:
 *   1. Open side panel when user clicks the toolbar icon
 *   2. Run the agent loop (CAPTURE → PERCEIVE → PLAN → ACT → repeat)
 *   3. Enforce MAX_STEPS / MAX_RUNTIME safety limits
 *   4. Honor stop / pause requests from the side panel
 *   5. Push timeline updates to the side panel (fire-and-forget)
 *   6. Optionally log sessions to the local backend (never required)
 *
 * The backend at localhost:8000 is OPTIONAL.
 * If it is unreachable the agent continues normally.
 */

import {
  createState, transition, isAborted, isOverLimit,
  STATUS, LIMITS, timelineEntry,
} from '../agent/state.js';
import { parseGoal, pickElement, isDestructive } from '../agent/planner.js';
import { executeAction, showOverlay, clearOverlay } from '../agent/actions.js';

// ── Open side panel on icon click ─────────────────────────────────────────
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

// ── Global agent state (one at a time) ────────────────────────────────────
let state = createState();

// ── Message router ─────────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  // Accept messages only from this extension's pages (side panel, offscreen, etc.)
  // Reject messages from web pages (content scripts run in page context but
  // chrome.runtime.sendMessage from content scripts also has sender.id === runtime.id)
  if (!msg || typeof msg !== 'object') return;

  // Offscreen document messages are handled by offscreen.js itself — ignore here
  // to avoid the service worker swallowing vision_infer responses.
  if (msg.type === 'vision_infer') return;

  switch (msg.type) {
    case 'agent_start':
      handleStart(msg.goal, msg.tabId).catch(console.error);
      sendResponse({ ok: true });
      return true;

    case 'agent_stop':
      state.stopRequested = true;
      sendResponse({ ok: true });
      return false;

    case 'agent_pause':
      state.pauseRequested = !state.pauseRequested;
      sendResponse({ paused: state.pauseRequested });
      return false;

    case 'agent_status':
      sendResponse({ status: state.status, step: state.stepIndex });
      return false;

    case 'confirm_destructive':
      _resolveDestructive?.(msg.confirmed);
      sendResponse({ ok: true });
      return false;

    default:
      // Unknown type — don't consume, let other listeners handle it
      return false;
  }
});

// ── Main agent loop ────────────────────────────────────────────────────────
async function handleStart(goal, tabId) {
  if (state.status !== STATUS.IDLE &&
      state.status !== STATUS.COMPLETED &&
      state.status !== STATUS.STOPPED &&
      state.status !== STATUS.ERROR) {
    pushTimeline('⚠ Agent already running');
    return;
  }

  // Reset state
  state = createState();
  state.goal      = goal;
  state.startedAt = Date.now();

  const steps = parseGoal(goal);
  if (steps.length === 0) {
    push(STATUS.ERROR, '✗ Could not parse goal — please rephrase');
    return;
  }
  state.steps = steps;

  push(STATUS.OBSERVING, `Goal: "${goal}"`, `${steps.length} step(s) planned`);

  // Optional: create backend session
  state.sessionId = await tryCreateSession(goal, tabId);

  // ── Step loop ──────────────────────────────────────────────────────────
  for (let si = 0; si < steps.length; si++) {
    state.stepIndex = si;
    const step = steps[si];

    if (isAborted(state)) break;

    const limit = isOverLimit(state);
    if (limit) {
      push(STATUS.STOPPED,
        `⚠ Safety limit reached (${limit})`,
        'Agent stopped — task could not complete within the safety limit.');
      break;
    }

    push(STATUS.OBSERVING, `Step ${si + 1}/${steps.length}: ${describeStep(step)}`);

    // Perception (with retries)
    let elements = null;
    let perceptionSource = 'dom';
    let inferenceMs = 0;

    for (let attempt = 0; attempt <= LIMITS.MAX_RETRIES; attempt++) {
      if (isAborted(state)) break;

      push(STATUS.PERCEIVING, attempt === 0 ? 'Capturing webpage…' : `Retry ${attempt}…`);

      const percResult = await perceive(tabId);
      if (percResult) {
        elements       = percResult.elements;
        perceptionSource = percResult.source;
        inferenceMs    = percResult.inferenceMs ?? 0;
        state.detectedElements = elements;
        state.perceptionMode   = perceptionSource;
        state.inferenceMs      = inferenceMs;

        push(STATUS.PERCEIVING,
          `${perceptionSource === 'vision' ? '👁 Vision' : '🔍 DOM'} — ${elements.length} elements detected`,
          `Inference: ${inferenceMs} ms | Mode: ${perceptionSource}`);

        pushPerceptionUpdate(elements, perceptionSource, inferenceMs);
        break;
      }

      if (attempt < LIMITS.MAX_RETRIES) {
        await sleep(800);
      }
    }

    if (!elements) {
      push(STATUS.ERROR, '✗ Perception failed after retries');
      break;
    }

    if (isAborted(state)) break;

    // Scroll has no target — execute immediately
    if (step.action === 'scroll') {
      push(STATUS.ACTING, `Scrolling ${step.direction ?? 'down'}`);
      const r = await executeAction(tabId, step, null);
      await tryLogAction(state.sessionId, step, null, r.ok);
      push(r.ok ? STATUS.WAITING : STATUS.ERROR,
        r.ok ? '↓ Scrolled' : `✗ Scroll failed: ${r.reason}`);
      if (!r.ok) { state.error = r.reason; break; }
      await sleep(600);
      continue;
    }

    // Plan — pick best matching element
    push(STATUS.PLANNING, `Looking for: "${step.target}"`);
    const target = pickElement(elements, step.target);
    state.selectedTarget = target;

    if (!target) {
      push(STATUS.WAITING,
        `⚠ Target not confidently identified: "${step.target}"`,
        'Low confidence — stopped safely. Try rephrasing the goal.');
      await clearOverlay(tabId);
      state.status = STATUS.STOPPED;
      break;
    }

    push(STATUS.PLANNING,
      `Target: ${target.text || target.label} (${Math.round((target.combinedConfidence ?? target.confidence) * 100)}% confidence)`);

    // Safety gate for destructive actions
    if (isDestructive(step)) {
      push(STATUS.WAITING, '⚠ Confirmation required for this action');
      const confirmed = await awaitDestructiveConfirmation(step);
      if (!confirmed) {
        push(STATUS.STOPPED, 'Action cancelled by user');
        await clearOverlay(tabId);
        state.status = STATUS.STOPPED;
        break;
      }
    }

    // Show overlay
    await showOverlay(tabId, target);
    await sleep(400);

    if (isAborted(state)) { await clearOverlay(tabId); break; }

    // Act
    push(STATUS.ACTING, `${step.action.toUpperCase()} → ${target.text || target.label}`);
    const result = await executeAction(tabId, step, target);
    state.lastAction = { type: step.action, target: target.text || target.label, ok: result.ok };

    await tryLogAction(state.sessionId, step, target, result.ok);

    if (!result.ok) {
      push(STATUS.ERROR, `✗ Action failed: ${result.reason}`);
      state.error = result.reason;
      await clearOverlay(tabId);
      break;
    }

    push(STATUS.WAITING,
      `✓ ${step.action.toUpperCase()} executed`,
      `Target: "${target.text || target.label}"`);

    // Wait for page to settle
    await sleep(step.action === 'click' ? 1200 : 400);
    await clearOverlay(tabId);

    // Handle pause
    while (state.pauseRequested && !state.stopRequested) {
      push(STATUS.WAITING, '⏸ Paused — click Resume to continue');
      await sleep(500);
    }
  }

  // ── End session ────────────────────────────────────────────────────────
  await clearOverlay(tabId).catch(() => {});

  if (isAborted(state)) {
    push(STATUS.STOPPED, '■ Agent stopped by user');
  } else if (state.status === STATUS.ACTING || state.status === STATUS.WAITING || state.status === STATUS.PLANNING) {
    push(STATUS.COMPLETED, '✓ Task complete');
  }

  await tryEndSession(state.sessionId,
    state.status === STATUS.COMPLETED ? 'success' : 'stopped');
}

// ── Perception helper ──────────────────────────────────────────────────────
async function perceive(tabId) {
  try {
    // 1. Capture screenshot — must pass explicit windowId in MV3
    const tab = await chrome.tabs.get(tabId);
    const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, {
      format: 'jpeg', quality: 70,
    });

    // 2. Try vision (ONNX offscreen) — returns null if model unavailable
    const visionResult = await tryVision(dataUrl);
    if (visionResult && visionResult.elements.length > 0) {
      return visionResult;
    }

    // 3. Ensure content script is injected (handles already-open tabs)
    await ensureContentScript(tabId);

    // 4. DOM fallback
    const domResult = await chrome.tabs.sendMessage(tabId, { type: 'dom_scan' })
      .catch(() => null);
    if (domResult?.elements) {
      return { elements: domResult.elements, source: 'dom', inferenceMs: 0 };
    }

    return null;
  } catch (err) {
    console.warn('[SightLite/bg] Perception error:', err.message);
    return null;
  }
}

// ── Inject content script if not already present ──────────────────────────
// Needed for tabs that were open before the extension was installed/reloaded.
async function ensureContentScript(tabId) {
  try {
    // Ping the content script — if it responds, it's already injected
    await chrome.tabs.sendMessage(tabId, { type: 'ping' });
  } catch {
    // No response → inject now
    try {
      await chrome.scripting.executeScript({
        target: { tabId },
        files: ['content/content.js'],
      });
      // Small wait for script to initialize
      await sleep(150);
    } catch (err) {
      console.warn('[SightLite/bg] Could not inject content script:', err.message);
    }
  }
}

// ── Offscreen ONNX vision ──────────────────────────────────────────────────
async function tryVision(dataUrl) {
  try {
    await ensureOffscreen();
    // Use a Promise that resolves from the sendMessage callback.
    // The service worker's own onMessage listener explicitly ignores
    // 'vision_infer' so this callback reaches the offscreen document.
    return await new Promise((resolve) => {
      const timeout = setTimeout(() => resolve(null), 8000);
      chrome.runtime.sendMessage({ type: 'vision_infer', dataUrl }, (result) => {
        clearTimeout(timeout);
        if (chrome.runtime.lastError) {
          // Offscreen not ready or inference failed — fall through to DOM
          resolve(null);
          return;
        }
        resolve(result ?? null);
      });
    });
  } catch {
    return null;
  }
}

async function ensureOffscreen() {
  const existing = await chrome.offscreen.hasDocument?.().catch(() => false);
  if (existing) return;
  try {
    await chrome.offscreen.createDocument({
      url:    'offscreen/offscreen.html',
      reasons: ['BLOBS'],
      justification: 'Run ONNX inference for visual perception',
    });
  } catch { /* already exists */ }
}

// ── Destructive action confirmation ───────────────────────────────────────
let _resolveDestructive = null;

function awaitDestructiveConfirmation(step) {
  return new Promise(resolve => {
    _resolveDestructive = resolve;
    pushToSidePanel({
      type:   'confirm_required',
      action: step.action,
      target: step.target,
      value:  step.value ?? '',
    });
    // Auto-deny after 30 s if user does not respond
    setTimeout(() => {
      _resolveDestructive = null;
      resolve(false);
    }, 30_000);
  });
}

// ── Side panel messaging ───────────────────────────────────────────────────
function push(status, label, detail = '') {
  transition(state, status);
  const entry = timelineEntry(label, detail);
  state.timeline.push(entry);
  pushToSidePanel({ type: 'timeline_update', status, entry });
}

function pushTimeline(label) {
  const entry = timelineEntry(label);
  state.timeline.push(entry);
  pushToSidePanel({ type: 'timeline_update', status: state.status, entry });
}

function pushPerceptionUpdate(elements, source, inferenceMs) {
  pushToSidePanel({
    type: 'perception_update',
    count: elements.length,
    source,
    inferenceMs,
  });
}

function pushToSidePanel(msg) {
  chrome.runtime.sendMessage(msg).catch(() => {
    // Side panel may not be open — that is fine
  });
}

// ── Optional backend helpers (fire-and-forget, never throw) ───────────────
const BACKEND = 'http://localhost:8000';

async function tryCreateSession(goal, tabId) {
  try {
    const tab = await chrome.tabs.get(tabId);
    const r = await fetchJSON(`${BACKEND}/sessions`, 'POST', { goal, url: tab.url });
    return r?.id ?? null;
  } catch { return null; }
}

async function tryLogAction(sessionId, step, target, ok) {
  if (!sessionId) return;
  try {
    await fetchJSON(`${BACKEND}/sessions/${sessionId}/actions`, 'POST', {
      type:   step.action,
      target: target?.text ?? step.target ?? '',
      value:  step.value  ?? '',
      ok,
    });
  } catch { /* backend optional */ }
}

async function tryEndSession(sessionId, status) {
  if (!sessionId) return;
  try {
    await fetchJSON(`${BACKEND}/sessions/${sessionId}/end`, 'POST', { status });
  } catch { /* backend optional */ }
}

async function fetchJSON(url, method, body) {
  const r = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
    signal: AbortSignal.timeout(3000),
  });
  return r.json();
}

// ── Utility ────────────────────────────────────────────────────────────────
const sleep = ms => new Promise(r => setTimeout(r, ms));

function describeStep(step) {
  if (step.action === 'scroll') return `scroll ${step.direction ?? 'down'}`;
  if (step.action === 'type')   return `type "${step.value}" in "${step.target}"`;
  return `${step.action} "${step.target}"`;
}
