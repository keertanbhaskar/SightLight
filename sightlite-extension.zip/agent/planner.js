/**
 * agent/planner.js
 * Deterministic ranked planner. Parses a natural-language goal into steps,
 * then selects the best matching element from a perception result.
 *
 * Ranking order (highest → lowest):
 *   1. Exact text match
 *   2. Exact label/role match
 *   3. Partial text match (includes)
 *   4. Aria-label / placeholder includes
 *   5. Role match with partial text
 *
 * Minimum confidence threshold: 0.35
 * If nothing meets the threshold → returns null (do NOT blindly act).
 */

// ── Goal parser ────────────────────────────────────────────────────────────
// Splits on "then" and classifies each clause.
// Supported intents:
//   click <target>
//   type "<value>" in <target>
//   scroll [down|up]
//   find <target>          → resolves to click after highlight
export function parseGoal(goal) {
  if (!goal || !goal.trim()) return [];

  return goal
    .trim()
    .split(/\s+then\s+/i)
    .map(clause => clause.trim())
    .filter(Boolean)
    .map(clause => {
      // type "value" in target
      let m = clause.match(/^type\s+"([^"]+)"\s+in\s+(.+)$/i);
      if (m) return { action: 'type', value: m[1], target: m[2].trim() };

      // type value in target (no quotes)
      m = clause.match(/^type\s+(\S+)\s+in\s+(.+)$/i);
      if (m) return { action: 'type', value: m[1], target: m[2].trim() };

      // scroll
      if (/^scroll(\s+(down|up))?$/i.test(clause)) {
        const dir = /up/i.test(clause) ? 'up' : 'down';
        return { action: 'scroll', direction: dir, target: null };
      }

      // find <target>
      m = clause.match(/^find\s+(.+)$/i);
      if (m) return { action: 'find', target: m[1].trim() };

      // click <target> (default)
      const target = clause.replace(/^click\s+/i, '').trim();
      return { action: 'click', target };
    });
}

// ── Element picker ─────────────────────────────────────────────────────────
const CONFIDENCE_THRESHOLD = 0.35;

export function pickElement(elements, targetKeyword) {
  if (!elements || elements.length === 0) return null;
  if (!targetKeyword) return null;

  const key = targetKeyword.toLowerCase().trim();

  const scored = elements
    .map(el => ({ el, score: score(el, key) }))
    .filter(({ score }) => score > 0)
    .sort((a, b) => b.score - a.score);

  if (scored.length === 0) return null;

  const best = scored[0];

  // Combine planner score with perception confidence
  const combinedConfidence = best.score * (best.el.confidence ?? 1.0);
  if (combinedConfidence < CONFIDENCE_THRESHOLD) return null;

  return { ...best.el, plannerScore: best.score, combinedConfidence };
}

function score(el, key) {
  const text  = (el.text  ?? '').toLowerCase();
  const label = (el.label ?? '').toLowerCase();
  const role  = (el.role  ?? '').toLowerCase();
  const aria  = (el.ariaLabel ?? '').toLowerCase();
  const ph    = (el.placeholder ?? '').toLowerCase();

  // Exact full text match — highest signal
  if (text === key)  return 1.0;
  if (label === key) return 0.95;
  if (role === key)  return 0.90;
  if (aria === key)  return 0.88;

  // Partial text match
  if (text.includes(key))  return 0.75;
  if (aria.includes(key))  return 0.65;
  if (ph.includes(key))    return 0.60;
  if (label.includes(key)) return 0.55;

  // Key words appear anywhere in text
  const words = key.split(/\s+/);
  if (words.length > 1) {
    const allInText = words.every(w => text.includes(w));
    if (allInText) return 0.50;
    const someInText = words.some(w => text.includes(w));
    if (someInText) return 0.30;
  }

  // Role is relevant to keyword (e.g. user said "button" and it is a button)
  if (role.includes(key) || key.includes(role)) return 0.25;

  return 0;
}

// ── Safety check ───────────────────────────────────────────────────────────
// Returns true if the action might be destructive and needs confirmation.
const DESTRUCTIVE_PATTERNS = [
  /\b(delete|remove|clear|reset|wipe)\b/i,
  /\b(submit|send|pay|purchase|buy|checkout|confirm|place order)\b/i,
  /\b(password|passcode|pin)\b/i,
  /\b(logout|sign out|deactivate|close account)\b/i,
];

export function isDestructive(step) {
  const text = `${step.action} ${step.target ?? ''} ${step.value ?? ''}`;
  return DESTRUCTIVE_PATTERNS.some(p => p.test(text));
}
